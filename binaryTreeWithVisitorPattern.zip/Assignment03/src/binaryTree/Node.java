package binaryTree;

public class Node {
	private int value;
	private Node parent;
	private Node rightNeighbor;
	
	public Node(int value) {
		this.value = value;
	}
	
	//get,set method
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	
	public Node getRightNeighbor() {
		return rightNeighbor;
	}
	public void setRightNeighbor(Node rightNeighbor) {
		this.rightNeighbor = rightNeighbor;
	}	
}

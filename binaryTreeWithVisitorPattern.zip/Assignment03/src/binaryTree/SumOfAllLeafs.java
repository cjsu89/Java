package binaryTree;

public class SumOfAllLeafs implements Visitor {

	private int sumOfAllLeafs;
	
	public SumOfAllLeafs() {
		sumOfAllLeafs = 0;
	}
	
	@Override
	public void visitor(BinaryTree binaryTree) {
		if(binaryTree instanceof ConcreteBinaryTree) {
			Node idx;
			idx = ((ConcreteBinaryTree) binaryTree).getKnownNode();
			
			while(true) {
				if(idx.getRightNeighbor() == null) {
					sumOfAllLeafs += idx.getValue();
					break;
				}else {
					sumOfAllLeafs += idx.getValue();
					idx = idx.getRightNeighbor();
				}
			}
		}

	}
	
	public int getSumOfAllLeafs() {
		return sumOfAllLeafs;
	}

}

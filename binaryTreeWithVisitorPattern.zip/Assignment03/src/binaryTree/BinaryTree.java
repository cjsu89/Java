package binaryTree;

public interface BinaryTree {
	public void accept(Visitor visitor);
}

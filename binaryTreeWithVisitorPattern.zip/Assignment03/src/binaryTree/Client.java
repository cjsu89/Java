package binaryTree;

public class Client {

	public static void main(String[] args) {
		
		//create BinaryTree
		ConcreteBinaryTree concreteBinaryTree = new ConcreteBinaryTree();
		concreteBinaryTree.add(5);
		concreteBinaryTree.add(7);			
		concreteBinaryTree.add(8);			
		concreteBinaryTree.add(15);			
		concreteBinaryTree.add(20);			
		concreteBinaryTree.add(21);			
		concreteBinaryTree.add(13);			
		concreteBinaryTree.add(18);			
		concreteBinaryTree.add(11);			
		concreteBinaryTree.add(42);
		
		//execute operations
		Visitor valueOfRoot = new ValueOfRoot();
		Visitor sumOfAllNodes = new SumOfAllNodes();
		Visitor sumOfAllLeafs = new SumOfAllLeafs();
		
		concreteBinaryTree.accept(valueOfRoot);
		concreteBinaryTree.accept(sumOfAllNodes);
		concreteBinaryTree.accept(sumOfAllLeafs);
		
		System.out.println("Value of root: "+((ValueOfRoot)valueOfRoot).getValueOfRoot());
		System.out.println("Sum of all nodes: "+((SumOfAllNodes)sumOfAllNodes).getSumOfAllNodes());
		System.out.println("Sum of all leafs: "+((SumOfAllLeafs)sumOfAllLeafs).getSumOfAllLeafs());
		
	}

}

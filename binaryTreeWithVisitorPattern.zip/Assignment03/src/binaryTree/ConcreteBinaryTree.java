package binaryTree;

public class ConcreteBinaryTree implements BinaryTree {
	
	private Node knownNode = null;
	private Node parentsIndex = null;
	private Node neighborIndex = null;
	
	public void add(int value) {
		Node node = new Node(value);
		if(knownNode == null) {//root node			
			knownNode = node;
			parentsIndex = node;
		}else {
			if(knownNode == parentsIndex) {//add first new hierarchy node
				node.setParent(knownNode);
				knownNode = node;
				neighborIndex = node;
			}else if(parentsIndex.getRightNeighbor() == null) {
				if(neighborIndex.getParent() == parentsIndex) {//add last node
					node.setParent(parentsIndex);
					neighborIndex.setRightNeighbor(node);
					parentsIndex = knownNode;
					neighborIndex = knownNode;
				}else if(neighborIndex.getParent() != parentsIndex) {//add new node
					node.setParent(parentsIndex);
					neighborIndex.setRightNeighbor(node);
					neighborIndex = node;
				}else {
					System.out.println("error1");
				}
			}else if(parentsIndex.getRightNeighbor() != null) {
				if(neighborIndex.getParent() == parentsIndex) {//add new node
					node.setParent(parentsIndex);
					neighborIndex.setRightNeighbor(node);
					parentsIndex = parentsIndex.getRightNeighbor();
					neighborIndex = node;
				}else if(neighborIndex.getParent() != parentsIndex) {//add new node
					node.setParent(parentsIndex);
					neighborIndex.setRightNeighbor(node);
					neighborIndex = node;
				}else {
					System.out.println("error2");
				}
			}else {
				System.out.println("error3");
			}
		}
	}
		
	@Override
	public void accept(Visitor visitor) {
		visitor.visitor(this);
	}
	
	public Node getKnownNode() {
		return knownNode;
	}
}

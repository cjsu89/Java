package binaryTree;

public class SumOfAllNodes implements Visitor {
	
	private int sumOfAllNodes;
	
	public SumOfAllNodes() {
		sumOfAllNodes =  0;
	}
	
	@Override
	public void visitor(BinaryTree binaryTree) {
		if(binaryTree instanceof ConcreteBinaryTree) {
			Node idx, idxleft;
			idxleft = ((ConcreteBinaryTree) binaryTree).getKnownNode();
			idx = idxleft;
			while(true){
				if(idx.getRightNeighbor() == null) {
					sumOfAllNodes += idx.getValue();
					if(idxleft.getParent() == null) {
						break;
					}else {
						idxleft = idxleft.getParent();
						idx = idxleft;
					}
				}else {
					sumOfAllNodes += idx.getValue();
					idx = idx.getRightNeighbor();
				}
			}
		}
	}
	
	public int getSumOfAllNodes() {
		return sumOfAllNodes;
	}

}

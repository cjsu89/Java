package binaryTree;

public interface Visitor {
	public void visitor(BinaryTree binaryTree);
}

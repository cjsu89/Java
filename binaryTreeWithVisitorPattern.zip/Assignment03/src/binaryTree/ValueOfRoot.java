package binaryTree;

public class ValueOfRoot implements Visitor {

	private int valueOfRoot;
	
	public ValueOfRoot() {
		valueOfRoot = 0;
	}
	
	@Override
	public void visitor(BinaryTree binaryTree) {
		if(binaryTree instanceof ConcreteBinaryTree) {
			Node idx;
			idx = ((ConcreteBinaryTree) binaryTree).getKnownNode();
			
			while(true) {
				if(idx.getParent() == null) {
					valueOfRoot = idx.getValue();
					break;
				}else {
					idx = idx.getParent();
				}
			}
			
		}
	}
	
	public int getValueOfRoot() {
		return valueOfRoot;
	}

}
